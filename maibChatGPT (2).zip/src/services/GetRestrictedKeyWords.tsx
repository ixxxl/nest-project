// const GetRestrictedKeyWords = (inputWords: any, restrictedWords: any) => {
//   const keyWord = ["maib"];
//   const result = keyWord.map((item: any) =>
//     inputWords.toLowerCase().includes(item.toLowerCase())
//   );
//   for (let i = 0; i < result.length; i++) {
//     if (result[i] === true) {
//       //denyAcces = result[i];
//     }
//   }
//   return keyWord;
// };
// export default GetRestrictedKeyWords;

import axios from "axios";

export class GetRestrictedKeyWords {
  public static getAllWords = async () => {
    const API = await axios
      .get("http://localhost:3001/words")
      .then(function (response) {
        const result = response.data;

        return result;
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .finally(function () {
        // always executed
      });

    return API;
  };
}
