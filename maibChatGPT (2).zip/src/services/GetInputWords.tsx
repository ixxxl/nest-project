// const GetInputWords = (props: any) => {
//   console.log(props);
//   // const words = props.match(/\b(\w+)\b/g)
//   const words = props.split(" ").filter((w: any) => w !== "");
//   console.log(words);

//   return words;
// };

// export default GetInputWords;

export class GetInputWords {
  static ListOfWords = (text: string): string[] => {
    const words = text.toLowerCase().split(" ").filter((w: any) => w !== "");
    console.log(words);
    return words;
  };
}

