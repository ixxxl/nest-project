export interface IRxWord {
  id: string;
  word: string;
}

export interface IUser {
  id: string;
  date: Date;
  question: string;
  restrictedWords: string;
  response: string;
  userID: string;
}
