import { TextField, Typography } from "@mui/material";
import {
  Controller,
  SubmitHandler,
  useForm,
  useFormState,
} from "react-hook-form";
import { ButtonS } from "../ChartPage/StyledComponent";
import { AuthForm, AuthFormSubtitle, AuthForm__Form } from "./styledAuthForm";
import { useState } from "react";

import React from "react";
import { useKeycloak } from "@react-keycloak/web";

interface IFieldsAuth {
  login?: string;
  password?: string;
}

const AuthPage = () => {
  const { handleSubmit, reset, control } = useForm<IFieldsAuth>({
    mode: "onBlur",
  });

  const { keycloak } = useKeycloak();
  const [username, setUsername] = useState<any>("");
  const [password, setPassword] = useState<any>("");

  const { errors } = useFormState({ control });

  const onSubmit: SubmitHandler<IFieldsAuth> = (data) => {
    // async (event: any) => {
    //   event.preventDefault();
    //   try {
    //     await keycloak.login();
    //   } catch (error) {
    //     console.error("Failed to log in", error);
    //   }
    // };
  };

  return (
    <>
      <AuthForm>
        <Typography variant="h4" component="h4" className="auth">
          Войдите
        </Typography>
        <AuthFormSubtitle variant="subtitle1">
          Чтобы получить доступ
        </AuthFormSubtitle>
        <AuthForm__Form>
          <Controller
            control={control}
            name="login"
            render={({ field }) => (
              <TextField
                label="login"
                size="small"
                helperText={errors.login && errors.login?.message}
                error={!!errors.login?.message}
                fullWidth={true}
                onChange={(e) => setUsername(field.onChange(e))}
                value={field.value}
                onBlur={field.onBlur}
              />
            )}
          />
          <Controller
            control={control}
            name="password"
            render={({ field }) => (
              <TextField
                label="password"
                type="password"
                size="small"
                sx={{ marginTop: 2 }}
                fullWidth={true}
                onChange={(e) => setPassword(field.onChange(e))}
                value={field.value}
                error={!!errors.password?.message}
                helperText={errors.password && errors.password?.message}
                onBlur={field.onBlur}
              />
            )}
          />
          <ButtonS type="submit" onClick={handleSubmit(onSubmit)}>
            Logheaza-te
          </ButtonS>
        </AuthForm__Form>
      </AuthForm>
    </>
  );
};

export default AuthPage;
