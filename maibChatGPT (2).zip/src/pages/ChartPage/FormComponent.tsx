import React, { useEffect, useState } from "react";
import { ButtonS, FormControl, InputSection } from "./StyledComponent";
import { Controller, useForm } from "react-hook-form";
import { InputLabel, TextField } from "@mui/material";
import { useQuestions } from "../../hooks/useQuestions";
import AnswerComponent from "./AnswerComponent";
import { GetInputWords } from "../../services/GetInputWords";
import { GetRestrictedKeyWords } from "../../services/GetRestrictedKeyWords";
import { IRxWord } from "../../models/models";
import { useAxiosGet } from "../../services/Axios";

const FormComponent = () => {
  const [newQuestion, setNewQuestion] = useState<string>("");

  const { control, handleSubmit } = useForm();
  const [words, setWords] = useState<any>([]);
  const [rgxWords, setRgxWords] = useState<any>();
  const [censuredWords, setCensuredWords] = useState<any>();
  const [refresh, setRefresh] = useState<boolean>(false);

  const { questions, requestAnswer, isLoading, isError } = useQuestions();

  const clickHandler = () => {
    const words = GetInputWords.ListOfWords(newQuestion);
    setWords(words);
    //requestAnswer(newQuestion);
    setRefresh(false);
  };

  useEffect(() => {
    if (words.length) {
      // declare the async data fetching function
      const fetchData = async () => {
        // get the data from the api
        const result = await GetRestrictedKeyWords.getAllWords();

        let wordsRestricted: IRxWord[] = [];
        try {
          wordsRestricted = result;
        } catch (error) {
          console.log(error); //todo#
        } finally {
          const resulRestrictedtWords = wordsRestricted.map(
            (item: IRxWord) => item.word
          );

          const a: string[] = [];
          words.map((word: string) => {
            if (resulRestrictedtWords.includes(word)) {
              a.push(word);
            }
          });
          setCensuredWords(a);
          setRgxWords(wordsRestricted);
          setRefresh(true);
        }
      };

      // call the function
      fetchData()
        // make sure to catch any error
        .catch(console.error);
    }
  }, [words]);

  useEffect(() => {
    if (refresh) {
      if (censuredWords.length) {
        console.log(`censured`);
        setNewQuestion("");
      } else {
        console.log(`Ok`);
        requestAnswer(newQuestion);

        setNewQuestion("");
      }
    }
  }, [refresh]);

  if (isError) return <p>Ops! Something went wrong</p>;

  return (
    <>
      {/* <FormControl> */}
      <InputSection>
        <InputLabel>
          <Controller
            control={control}
            name="Input"
            render={({
              field: { onChange, onBlur, value, name, ref },
              fieldState: { invalid, isTouched, isDirty, error },
              formState,
            }) => (
              <TextField
                fullWidth
                placeholder="Întreabă orice"
                rows={3}
                multiline
                onBlur={onBlur} // notify when input is touched
                onChange={(event) => {
                  setNewQuestion(event.target.value);
                }} // send value to hook form
                value={newQuestion}
                inputRef={ref}
              />
            )}
          />

          {/* </FormControl> */}
        </InputLabel>
      </InputSection>
      <ButtonS onClick={handleSubmit(clickHandler)} disabled={isLoading}>
        Send
      </ButtonS>
      <AnswerComponent
        isLoading={isLoading}
        questions={questions}
        isError={isError}
      />
      <div>Step 1 InputWords</div>
      <pre style={{ textAlign: "left" }}>{JSON.stringify(words, null, 2)}</pre>
      <div>Step 2 Restricted Words</div>
      <pre style={{ textAlign: "left" }}>
        {JSON.stringify(rgxWords, null, 2)}
      </pre>
      <div>Step 3 Verify Restricted Words</div>
      <pre style={{ textAlign: "left" }}>
        {JSON.stringify(censuredWords, null, 2)}
      </pre>
    </>
  );
};

export default FormComponent;
