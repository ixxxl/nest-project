import Keycloak from "keycloak-js";

const keycloak = new Keycloak({
  url: "http://tkeycloak.maib.test/",
  // url: "https://tkc.maib.test",
  realm: "test",
  clientId: "chat",
});

export default keycloak;
