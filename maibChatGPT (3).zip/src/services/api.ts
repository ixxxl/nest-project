import axios from "axios";

export const client = axios.create({
  baseURL: "http://localhost:3005",
});
export const createUser = async (
  name: string,
  lastname: string,
  password: string,
) => {
  const user = { name, lastname, password };
  return await client.post("/auth/create", user);
};

export const reqAnswer = async (
  message: string
) => {
  return await client.post("/chat", {message});
}
