import FormComponent from "./pages/ChartPage/FormComponent";
import { Header } from "./pages/ChartPage/StyledComponent";
import GlobalStyleComponent from "./pages/ChartPage/GlobalStyleComponent";
import { QueryClient, QueryClientProvider } from "react-query";
import { useKeycloak } from "@react-keycloak/web";
import AuthPage from "./pages/AuthPage/AuthPage";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import keycloak from "./services/KeyCloak";
import { ReactKeycloakProvider } from "@react-keycloak/web";

function App() {
  const queryClient = new QueryClient();

  return (
    <div>
      {/* <ReactKeycloakProvider authClient={keycloak}> */}
        <QueryClientProvider client={queryClient}>
          <Header>
            <GlobalStyleComponent />
            <h1>ChatGPT maib</h1>
            <p>Internal chat</p>
          </Header>
          <FormComponent />
        </QueryClientProvider>
      {/* </ReactKeycloakProvider> */}
    </div>
  );
}

export default App;
